if (!isGeneric("clhs"))
  setGeneric("clhs", function(x, ...)
    standardGeneric("clhs"))